#!/usr/bin/env bash

curl -sX PUT http://127.0.0.1:5984/$1
