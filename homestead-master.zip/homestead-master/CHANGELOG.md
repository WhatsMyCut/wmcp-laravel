# Release Notes

Please visit https://github.com/laravel/homestead/releases for details about each release.

Official documentation [is located here](https://laravel.com/docs/homestead).
